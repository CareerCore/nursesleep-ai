import pandas as pd


def occupation_summary(df: pd.DataFrame) -> pd.DataFrame:
    required = {"occupation", "sleep_duration_hrs", "stress_score",
                "sleep_quality_score", "cognitive_performance_score"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}")

    return (
        df.groupby("occupation", dropna=False)
        .agg(
            records=("occupation", "size"),
            mean_sleep_hours=("sleep_duration_hrs", "mean"),
            mean_stress=("stress_score", "mean"),
            mean_sleep_quality=("sleep_quality_score", "mean"),
            mean_cognitive_score=("cognitive_performance_score", "mean"),
        )
        .round(2)
        .sort_values("records", ascending=False)
    )


def shift_work_summary(df: pd.DataFrame) -> pd.DataFrame:
    required = {"shift_work", "sleep_duration_hrs", "stress_score",
                "cognitive_performance_score"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}")

    return (
        df.groupby("shift_work", dropna=False)
        .agg(
            records=("shift_work", "size"),
            mean_sleep_hours=("sleep_duration_hrs", "mean"),
            mean_stress=("stress_score", "mean"),
            mean_cognitive_score=("cognitive_performance_score", "mean"),
        )
        .round(2)
    )
