from pathlib import Path
import pandas as pd


def load_dataset(path: str | Path) -> pd.DataFrame:
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(
            f"Dataset not found at {path}. Run: python -m nursesleep_ai.download_data"
        )
    return pd.read_csv(path)


def audit_dataset(df: pd.DataFrame) -> dict:
    return {
        "rows": int(df.shape[0]),
        "columns": int(df.shape[1]),
        "duplicate_rows": int(df.duplicated().sum()),
        "missing_cells": int(df.isna().sum().sum()),
        "missing_by_column": df.isna().sum().sort_values(ascending=False),
        "dtypes": df.dtypes.astype(str),
    }


def nursing_subset(df: pd.DataFrame) -> pd.DataFrame:
    if "occupation" not in df.columns:
        return df.iloc[0:0].copy()
    mask = df["occupation"].astype("string").str.strip().str.casefold().eq("nurse")
    return df.loc[mask.fillna(False)].copy()
