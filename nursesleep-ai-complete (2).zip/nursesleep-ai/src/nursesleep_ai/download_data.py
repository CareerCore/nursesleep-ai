from pathlib import Path
from urllib.request import urlopen
from .config import DATA_DIR, DATA_PATH, DATA_URL


def download_dataset(overwrite: bool = False) -> Path:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    if DATA_PATH.exists() and not overwrite:
        print(f"Dataset already exists: {DATA_PATH}")
        return DATA_PATH

    print(f"Downloading dataset from: {DATA_URL}")
    with urlopen(DATA_URL, timeout=60) as response:
        content = response.read()

    if not content:
        raise RuntimeError("Downloaded file is empty.")

    DATA_PATH.write_bytes(content)
    print(f"Saved dataset to: {DATA_PATH}")
    return DATA_PATH


if __name__ == "__main__":
    download_dataset()
