from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[2]
DATA_DIR = PROJECT_ROOT / "data"
RESULTS_DIR = PROJECT_ROOT / "results"
DATA_PATH = DATA_DIR / "sleep_health_dataset.csv"
DATA_URL = (
    "https://raw.githubusercontent.com/mohan13krishna/"
    "Sleep-Health-Daily-Performance-Dataset/main/"
    "sleep_health_dataset.csv"
)
RANDOM_STATE = 42
TARGET_COLUMNS = [
    "felt_rested",
    "sleep_disorder_risk",
    "cognitive_performance_score",
]
IDENTIFIER_COLUMNS = ["person_id"]
