# Data

The dataset is intentionally not committed to this repository.

Download it from the source:

`https://raw.githubusercontent.com/mohan13krishna/Sleep-Health-Daily-Performance-Dataset/main/sleep_health_dataset.csv`

Run:

```bash
python -m nursesleep_ai.download_data
```

The file will be saved as `data/sleep_health_dataset.csv`.

Credit: Mohan Krishna Thalla, Sleep Health & Daily Performance Dataset.

The dataset has been described as synthetic. Check the original source for its current licence and attribution requirements before use or redistribution. Do not upload the data to this repository unless the source terms permit it.
