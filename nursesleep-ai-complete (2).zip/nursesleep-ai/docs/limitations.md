# Limitations and responsible use

1. The dataset is described as synthetic; it should not be treated as a representative sample of nurses or any workforce.
2. Dataset variable definitions, provenance, and licence should be verified at the original source.
3. A category named `Nurse` does not establish that records correspond to real nurses.
4. Cross-sectional or simulated associations cannot establish causation.
5. Random row splits may overestimate performance if multiple rows belong to the same person. Use group-aware validation if repeated-person identifiers exist.
6. Model scores depend on class balance, data generation, label construction, and the selected split.
7. Predictions are not diagnoses and must not be used for clinical decisions, fitness-for-duty assessments, hiring, or employment decisions.
8. Real-world research requires appropriate ethics review, informed governance, privacy protections, representative data, and external validation.
