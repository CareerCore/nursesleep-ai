# Methodology

## Study design

A secondary, exploratory analysis of the Sleep Health & Daily Performance Dataset. The analysis is descriptive and predictive within the supplied dataset; it is not a clinical study.

## Analysis populations

1. Full dataset: all valid rows available after basic data checks.
2. Nursing-labelled subgroup: rows where the normalised `occupation` value equals `nurse`. If this category is absent, the subgroup analysis is skipped and documented.
3. Shift-work groups: categories observed in `shift_work`; their exact labels are inspected rather than assumed.

## Data preparation

- Preserve the raw downloaded CSV.
- Inspect dimensions, data types, missingness, duplicates, and category values.
- Do not silently delete rows or impute values during descriptive analysis.
- For modelling, imputation and categorical encoding are fitted inside scikit-learn pipelines on training data only.
- Exclude identifier columns and designated outcome columns from model predictors to reduce leakage risk.

## Modelling

Baseline tasks:
- Classification target: `felt_rested`.
- Regression target: `cognitive_performance_score`.

A fixed random train/test split is used as an initial baseline. Classification uses stratification where possible. If records are repeated for the same person, a group-aware split is required before reporting final generalisation estimates.

## Evaluation

Classification: accuracy, precision, recall, F1, confusion matrix, and ROC-AUC only when supported by the target structure.

Regression: MAE, RMSE, and R-squared.

## Interpretation

All findings are dataset-specific. Associations are not causal effects. Predictive importance does not establish biological, clinical, or occupational mechanisms.
