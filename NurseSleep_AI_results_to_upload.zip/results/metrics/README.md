# Model metrics

## Random Forest classification: `felt_rested`

| Model | Target | Accuracy | Precision | Recall | F1 score |
|---|---|---:|---:|---:|---:|
| Random Forest Classifier | `felt_rested` | 0.738850 | 0.735263 | 0.738850 | 0.735472 |

These values are the results supplied for this run. They describe performance on the evaluation split used by the notebook and should not be interpreted as clinical performance or as evidence about real nurses. The dataset is synthetic, so findings are exploratory only.

**Metric order note:** The four supplied values have been labelled accuracy, precision, recall, and F1 score respectively. If your Colab output used a different metric order, rename the CSV columns and table headings to match that output before committing.
