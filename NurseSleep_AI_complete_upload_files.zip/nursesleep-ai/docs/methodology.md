# Methodology

## 1. Input and validation
The workflow reads a user-supplied local CSV, reports its dimensions, column names, data types, missing values and duplicate rows, and saves audit tables.

## 2. Exploratory analysis
Numeric variables are summarised and plotted. If occupation or shift-work fields are available, grouped summaries are generated. The workflow does not assume that every dataset contains every expected field.

## 3. Baseline modelling
When `felt_rested` is present, a Random Forest classifier is trained using the remaining eligible columns. When `cognitive_performance_score` is present, a Random Forest regressor is trained. Identifier-like columns and the other target columns are excluded from predictors by default.

## 4. Evaluation
A held-out split is used with a fixed random seed. Classification metrics include accuracy, precision, recall and F1. Regression metrics include MAE, RMSE and R-squared.

## 5. Reproducibility
The input path, random seed and output directories are explicit. Generated outputs are written beneath `results/`.
