# Limitations and responsible use

- Results depend on the quality, provenance, representativeness and permitted use of the locally supplied data.
- Exploratory associations do not establish causation.
- Random row splitting may overstate performance if multiple rows belong to the same person. Use a person-level grouped split when repeated-subject records exist.
- Predictive metrics do not establish clinical validity or generalisation to a new population.
- Do not use this project for diagnosis, treatment, fitness-for-duty or employment screening.
- Ensure appropriate permissions, privacy safeguards and governance before analysing any personal or sensitive data.
