"""Auditing, exploratory analysis and baseline modelling for a local CSV."""
from __future__ import annotations

import argparse
from pathlib import Path
import warnings

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    mean_absolute_error, mean_squared_error, r2_score,
)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder


ROOT = Path.cwd()
RESULTS = ROOT / "results"
FIGURES = RESULTS / "figures"
TABLES = RESULTS / "tables"
METRICS = RESULTS / "metrics"
RANDOM_STATE = 42


def make_dirs() -> None:
    for folder in (FIGURES, TABLES, METRICS):
        folder.mkdir(parents=True, exist_ok=True)


def audit_data(df: pd.DataFrame) -> None:
    audit = pd.DataFrame({
        "metric": ["rows", "columns", "duplicate_rows"],
        "value": [len(df), df.shape[1], int(df.duplicated().sum())],
    })
    audit.to_csv(TABLES / "dataset_audit.csv", index=False)
    df.isna().sum().rename("missing_count").to_csv(TABLES / "missing_values.csv")
    df.dtypes.astype(str).rename("dtype").to_csv(TABLES / "column_types.csv")
    df.describe(include="all").transpose().to_csv(TABLES / "descriptive_summary.csv")
    print(f"Loaded {df.shape[0]:,} rows and {df.shape[1]:,} columns.")


def exploratory_analysis(df: pd.DataFrame) -> None:
    numeric = df.select_dtypes(include=np.number)
    if not numeric.empty:
        numeric.hist(figsize=(14, 10), bins=30)
        plt.tight_layout()
        plt.savefig(FIGURES / "numeric_distributions.png", dpi=160)
        plt.close()

        if numeric.shape[1] >= 2:
            plt.figure(figsize=(12, 9))
            sns.heatmap(numeric.corr(), cmap="coolwarm", center=0)
            plt.title("Numeric feature correlation")
            plt.tight_layout()
            plt.savefig(FIGURES / "numeric_correlation_heatmap.png", dpi=160)
            plt.close()

    occupation_col = next((c for c in df.columns if c.lower() in {"occupation", "job", "profession"}), None)
    if occupation_col:
        df[occupation_col].value_counts(dropna=False).rename_axis(occupation_col).to_csv(
            TABLES / "occupation_counts.csv"
        )

    shift_col = next((c for c in df.columns if c.lower() in {"shift_work", "shiftwork", "shift"}), None)
    if shift_col:
        df[shift_col].value_counts(dropna=False).rename_axis(shift_col).to_csv(
            TABLES / "shift_work_counts.csv"
        )


def build_preprocessor(X: pd.DataFrame) -> ColumnTransformer:
    numeric_cols = X.select_dtypes(include=np.number).columns.tolist()
    categorical_cols = [c for c in X.columns if c not in numeric_cols]

    numeric_pipe = Pipeline([("imputer", SimpleImputer(strategy="median"))])
    categorical_pipe = Pipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore")),
    ])
    return ColumnTransformer([
        ("numeric", numeric_pipe, numeric_cols),
        ("categorical", categorical_pipe, categorical_cols),
    ], remainder="drop")


def model_classification(df: pd.DataFrame, target: str = "felt_rested") -> None:
    if target not in df.columns:
        print(f"Skipping classification: target '{target}' not found.")
        return
    work = df.dropna(subset=[target]).copy()
    y = work[target]
    if y.nunique() < 2:
        print(f"Skipping classification: '{target}' has fewer than two classes.")
        return
    drop_cols = [c for c in ["person_id", "id", target, "sleep_disorder_risk",
                              "cognitive_performance_score"] if c in work.columns]
    X = work.drop(columns=drop_cols)
    if X.empty:
        print("Skipping classification: no eligible predictor columns.")
        return
    stratify = y if y.value_counts().min() >= 2 else None
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=RANDOM_STATE, stratify=stratify
    )
    model = Pipeline([
        ("preprocess", build_preprocessor(X_train)),
        ("model", RandomForestClassifier(
            n_estimators=200, random_state=RANDOM_STATE, n_jobs=-1,
            class_weight="balanced_subsample"
        )),
    ])
    model.fit(X_train, y_train)
    pred = model.predict(X_test)
    average = "binary" if y.nunique() == 2 else "weighted"
    if average == "binary" and not set(pd.Series(y_test).unique()).issubset({0, 1}):
        average = "binary"
        # sklearn's binary metrics accept string labels as well.
    scores = {
        "model": "Random Forest Classifier",
        "target": target,
        "accuracy": accuracy_score(y_test, pred),
        "precision": precision_score(y_test, pred, average=average, zero_division=0),
        "recall": recall_score(y_test, pred, average=average, zero_division=0),
        "f1_score": f1_score(y_test, pred, average=average, zero_division=0),
        "averaging_method": average,
        "test_size": 0.2,
        "random_state": RANDOM_STATE,
    }
    pd.DataFrame([scores]).to_csv(METRICS / "felt_rested_random_forest.csv", index=False)
    print("Classification metrics:", scores)


def model_regression(df: pd.DataFrame, target: str = "cognitive_performance_score") -> None:
    if target not in df.columns:
        print(f"Skipping regression: target '{target}' not found.")
        return
    work = df.dropna(subset=[target]).copy()
    y = pd.to_numeric(work[target], errors="coerce")
    valid = y.notna()
    work, y = work.loc[valid], y.loc[valid]
    drop_cols = [c for c in ["person_id", "id", target, "felt_rested",
                              "sleep_disorder_risk"] if c in work.columns]
    X = work.drop(columns=drop_cols)
    if X.empty or len(work) < 10:
        print("Skipping regression: insufficient rows or no eligible predictors.")
        return
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=RANDOM_STATE
    )
    model = Pipeline([
        ("preprocess", build_preprocessor(X_train)),
        ("model", RandomForestRegressor(
            n_estimators=200, random_state=RANDOM_STATE, n_jobs=-1
        )),
    ])
    model.fit(X_train, y_train)
    pred = model.predict(X_test)
    scores = {
        "model": "Random Forest Regressor",
        "target": target,
        "mae": mean_absolute_error(y_test, pred),
        "rmse": float(np.sqrt(mean_squared_error(y_test, pred))),
        "r2": r2_score(y_test, pred),
        "test_size": 0.2,
        "random_state": RANDOM_STATE,
    }
    pd.DataFrame([scores]).to_csv(METRICS / "cognitive_performance_random_forest.csv", index=False)
    plt.figure(figsize=(7, 6))
    plt.scatter(y_test, pred, alpha=0.45)
    low, high = min(y_test.min(), pred.min()), max(y_test.max(), pred.max())
    plt.plot([low, high], [low, high], linestyle="--")
    plt.xlabel("Actual")
    plt.ylabel("Predicted")
    plt.title("Random Forest regression: actual vs predicted")
    plt.tight_layout()
    plt.savefig(FIGURES / "cognitive_performance_actual_vs_predicted.png", dpi=160)
    plt.close()
    print("Regression metrics:", scores)


def run(input_path: str) -> None:
    make_dirs()
    path = Path(input_path)
    if not path.exists():
        raise FileNotFoundError(
            f"Input CSV not found: {path}. Put your authorised CSV at data/input.csv "
            "or pass --input /path/to/file.csv."
        )
    df = pd.read_csv(path)
    if df.empty:
        raise ValueError("The input CSV has no rows.")
    audit_data(df)
    exploratory_analysis(df)
    model_classification(df)
    model_regression(df)
    print(f"Completed. Outputs saved under: {RESULTS.resolve()}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", default="data/input.csv", help="Path to the local input CSV")
    args = parser.parse_args()
    run(args.input)


if __name__ == "__main__":
    main()
