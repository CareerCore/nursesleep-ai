# Local input data

Place the CSV file you are authorised to analyse here and name it `input.csv`.

The actual input file is excluded from Git by the repository `.gitignore`. Do not commit private, confidential, restricted or unauthorised data.
