# Model evaluation metrics

The CSV in this folder records the classification values supplied for the current project run. Verify metric order, averaging method and test split against the original notebook output before citing the result in a report.

Do not treat this result as clinical validation or evidence about a real-world population.
