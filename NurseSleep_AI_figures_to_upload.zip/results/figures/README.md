# Figures

These three figures are alternative visual presentations of the same four supplied
Random Forest classification metrics for the `felt_rested` target:

- `felt_rested_metrics_bar.png`
- `felt_rested_metrics_horizontal.png`
- `felt_rested_metrics_dotplot.png`

They are not three independent analyses. No dataset-level distribution, occupation,
shift-work, confusion-matrix, ROC, or regression figures are included because the
underlying row-level data or prediction outputs were not supplied for those plots.

Verify metric definitions and averaging method against the original notebook output.
